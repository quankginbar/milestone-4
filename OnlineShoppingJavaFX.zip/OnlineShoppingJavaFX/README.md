# Online Shopping System - JavaFX Desktop App

## Requirements
- JDK 17 or later (JDK 21 recommended)
- Maven 3.8+ (VS Code can use its Java/Maven extensions)
- Internet connection for the first Maven run to download JavaFX dependencies

## Run in VS Code
1. Extract this ZIP.
2. In VS Code choose **File > Open Folder...** and select `OnlineShoppingJavaFX` (the folder containing `pom.xml`).
3. Open **Terminal > New Terminal**.
4. Run:
   ```powershell
   mvn clean javafx:run
   ```
   On Windows, if Maven is not installed, install Maven or use a Maven-enabled Java setup in VS Code.

## Features
- Customer tab: search products, add/remove cart items, checkout, order history.
- Admin tab: add products and increase/decrease stock.
- Existing model, service, and exception classes are reused.
- Sample products are created at startup; data is stored in memory and resets when the app closes.

## Important limitations
- This is a learning/demo application, not production-ready.
- There is no database or real payment gateway yet.
- The Admin tab is not protected by login/roles; it is for demonstrating OOP functionality.
