Online Shopping System - Core Implementation

Requirements: JDK 17 or later.

Compile from the project root:
    javac -d out src/model/*.java src/exception/*.java src/service/*.java src/Main.java

Run:
    java -cp out Main

Collections:
- HashMap<String, Product>: fast product lookup by product ID.
- LinkedHashMap<Product, Integer>: cart/order items and quantities.
- ArrayList<Order> and ArrayList<ShippingAddress>: customer history and addresses.

Exception handling:
- IllegalArgumentException: invalid input or invalid state.
- OutOfStockException: insufficient stock.
- InvalidOrderException: invalid checkout/cancellation/order lookup.

Note:
This is an in-memory educational implementation. Passwords are plain text and payment
processing is simulated; do not use this directly in production. Product lookup currently
uses IllegalArgumentException rather than ProductNotFoundException for simplicity.
