package app;

import exception.InvalidOrderException;
import exception.OutOfStockException;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Category;
import model.Customer;
import model.Order;
import model.Product;
import model.ShippingAddress;
import service.OrderService;
import service.ProductService;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public class ShoppingApp extends Application {
    private final ProductService productService = new ProductService();
    private final OrderService orderService = new OrderService();
    private final Customer customer = new Customer("U01", "customer", "customer@example.com", "demo123");
    private final Category defaultCategory = new Category("CAT01", "General", "General products");

    private final ObservableList<Product> visibleProducts = FXCollections.observableArrayList();
    private TableView<Product> productTable;
    private TableView<Product> adminTable;
    private TextArea cartArea;
    private TextArea historyArea;
    private TextField searchField;
    private TextField quantityField;
    private Label totalLabel;
    private int nextProductId = 3;

    @Override
    public void start(Stage stage) {
        seedProducts();
        TabPane tabs = new TabPane();
        tabs.getTabs().add(new Tab("Customer", createCustomerTab()));
        tabs.getTabs().add(new Tab("Admin", createAdminTab()));
        tabs.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        Label heading = new Label("ONLINE SHOPPING SYSTEM");
        heading.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
        VBox root = new VBox(12, heading, tabs);
        root.setPadding(new Insets(16));

        stage.setTitle("Online Shopping System");
        stage.setScene(new Scene(root, 950, 650));
        stage.show();
        refreshProducts("");
        refreshAdminTable();
        refreshCart();
        refreshHistory();
    }

    private void seedProducts() {
        productService.addProduct(new Product("P01", "Wireless Mouse",
                new BigDecimal("250000"), 10, "A wireless mouse", defaultCategory));
        productService.addProduct(new Product("P02", "Keyboard",
                new BigDecimal("500000"), 5, "A computer keyboard", defaultCategory));
    }

    private VBox createCustomerTab() {
        searchField = new TextField();
        searchField.setPromptText("Search product by name...");
        Button searchButton = new Button("Search");
        Button showAllButton = new Button("Show all");
        searchButton.setOnAction(e -> refreshProducts(searchField.getText()));
        showAllButton.setOnAction(e -> {
            searchField.clear();
            refreshProducts("");
        });
        HBox searchBar = new HBox(8, searchField, searchButton, showAllButton);
        HBox.setHgrow(searchField, Priority.ALWAYS);

        productTable = new TableView<>(visibleProducts);
        productTable.setPlaceholder(new Label("No products found."));
        productTable.getColumns().addAll(
                column("ID", "id", 80),
                column("Product", "name", 220),
                column("Price (VND)", "price", 130),
                column("Stock", "stock", 80));
        productTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        productTable.setPrefHeight(230);

        quantityField = new TextField("1");
        quantityField.setPrefWidth(70);
        Button addButton = new Button("Add selected product to cart");
        addButton.setOnAction(e -> addSelectedProduct());
        HBox addRow = new HBox(10, new Label("Quantity:"), quantityField, addButton);
        addRow.setPadding(new Insets(8, 0, 8, 0));

        cartArea = new TextArea();
        cartArea.setEditable(false);
        cartArea.setPrefRowCount(6);
        totalLabel = new Label("Total: 0 VND");
        totalLabel.setStyle("-fx-font-size: 15px; -fx-font-weight: bold;");
        Button removeButton = new Button("Remove selected cart item");
        Button checkoutButton = new Button("Checkout");
        removeButton.setOnAction(e -> removeSelectedCartItem());
        checkoutButton.setOnAction(e -> checkout());
        HBox cartButtons = new HBox(10, removeButton, checkoutButton);

        historyArea = new TextArea();
        historyArea.setEditable(false);
        historyArea.setPrefRowCount(4);
        VBox box = new VBox(8,
                new Label("PRODUCTS"), searchBar, productTable, addRow,
                new Separator(), new Label("YOUR CART"), cartArea, totalLabel, cartButtons,
                new Separator(), new Label("ORDER HISTORY"), historyArea);
        box.setPadding(new Insets(12));
        return box;
    }

    private VBox createAdminTab() {
        adminTable = new TableView<>();
        adminTable.getColumns().addAll(
                column("ID", "id", 80),
                column("Product", "name", 220),
                column("Price (VND)", "price", 130),
                column("Stock", "stock", 80));
        adminTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        adminTable.setPrefHeight(300);

        TextField nameField = new TextField();
        nameField.setPromptText("Product name");
        TextField priceField = new TextField();
        priceField.setPromptText("Price (VND)");
        TextField stockField = new TextField();
        stockField.setPromptText("Initial stock");
        TextField descriptionField = new TextField();
        descriptionField.setPromptText("Description");
        Button addProductButton = new Button("Add product");
        addProductButton.setOnAction(e -> {
            try {
                String name = nameField.getText().trim();
                BigDecimal price = new BigDecimal(priceField.getText().trim());
                int stock = Integer.parseInt(stockField.getText().trim());
                String id = String.format("P%02d", nextProductId);
                Product product = new Product(id, name, price, stock,
                        descriptionField.getText().trim(), defaultCategory);
                productService.addProduct(product);
                nextProductId++;
                nameField.clear(); priceField.clear(); stockField.clear(); descriptionField.clear();
                refreshAdminTable();
                refreshProducts(searchField == null ? "" : searchField.getText());
                showInfo("Product added successfully: " + id);
            } catch (NumberFormatException ex) {
                showError("Price and stock must be valid numbers.");
            } catch (IllegalArgumentException ex) {
                showError(ex.getMessage());
            }
        });

        TextField stockChangeField = new TextField("1");
        stockChangeField.setPromptText("Change (+/-)");
        Button updateStockButton = new Button("Update selected stock");
        updateStockButton.setOnAction(e -> {
            Product selected = adminTable.getSelectionModel().getSelectedItem();
            if (selected == null) {
                showError("Please select a product in the table first.");
                return;
            }
            try {
                int change = Integer.parseInt(stockChangeField.getText().trim());
                productService.updateInventory(selected.getId(), change);
                refreshAdminTable();
                refreshProducts(searchField == null ? "" : searchField.getText());
                refreshCart();
                showInfo("Stock updated successfully.");
            } catch (NumberFormatException ex) {
                showError("Stock change must be an integer. Use a negative number to reduce stock.");
            } catch (IllegalArgumentException ex) {
                showError(ex.getMessage());
            }
        });

        GridPane form = new GridPane();
        form.setHgap(8); form.setVgap(8);
        form.add(new Label("Name:"), 0, 0); form.add(nameField, 1, 0);
        form.add(new Label("Price:"), 2, 0); form.add(priceField, 3, 0);
        form.add(new Label("Stock:"), 0, 1); form.add(stockField, 1, 1);
        form.add(new Label("Description:"), 2, 1); form.add(descriptionField, 3, 1);
        form.add(addProductButton, 3, 2);
        ColumnConstraints c1 = new ColumnConstraints();
        ColumnConstraints c2 = new ColumnConstraints(); c2.setHgrow(Priority.ALWAYS);
        ColumnConstraints c3 = new ColumnConstraints();
        ColumnConstraints c4 = new ColumnConstraints(); c4.setHgrow(Priority.ALWAYS);
        form.getColumnConstraints().addAll(c1, c2, c3, c4);

        HBox stockRow = new HBox(10, new Label("Stock change (+/-):"), stockChangeField, updateStockButton);
        VBox box = new VBox(12, new Label("INVENTORY"), adminTable,
                new Separator(), new Label("ADD NEW PRODUCT"), form,
                new Separator(), stockRow);
        box.setPadding(new Insets(12));
        return box;
    }

    private <T> TableColumn<Product, String> column(String title, String field, double width) {
        TableColumn<Product, String> col = new TableColumn<>(title);
        col.setPrefWidth(width);
        col.setCellValueFactory(data -> {
            Product p = data.getValue();
            String value;
            switch (field) {
                case "id": value = p.getId(); break;
                case "name": value = p.getName(); break;
                case "price": value = p.getPrice().toPlainString(); break;
                default: value = String.valueOf(p.getStock());
            }
            return new javafx.beans.property.SimpleStringProperty(value);
        });
        return col;
    }

    private void refreshProducts(String query) {
        List<Product> products = query == null || query.isBlank()
                ? productService.searchProducts("") : productService.searchProducts(query.trim());
        // An empty search query matches all product names.
        visibleProducts.setAll(products);
    }

    private void refreshAdminTable() {
        if (adminTable != null) {
            adminTable.getItems().setAll(productService.searchProducts(""));
        }
    }

    private void addSelectedProduct() {
        Product selected = productTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showError("Please select a product first.");
            return;
        }
        try {
            int quantity = Integer.parseInt(quantityField.getText().trim());
            customer.getCart().addItem(selected, quantity);
            refreshCart();
            showInfo("Product added to cart.");
        } catch (NumberFormatException ex) {
            showError("Quantity must be an integer.");
        } catch (OutOfStockException | IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }

    private void removeSelectedCartItem() {
        List<Map.Entry<Product, Integer>> items = customer.getCart().getItems().entrySet().stream().toList();
        if (items.isEmpty()) {
            showError("Your cart is empty.");
            return;
        }
        ChoiceDialog<Product> dialog = new ChoiceDialog<>(items.get(0).getKey(),
                items.stream().map(Map.Entry::getKey).toList());
        dialog.setTitle("Remove cart item");
        dialog.setHeaderText("Select a product to remove");
        dialog.setContentText("Product:");
        dialog.showAndWait().ifPresent(product -> {
            customer.getCart().removeItem(product);
            refreshCart();
        });
    }

    private void refreshCart() {
        if (cartArea == null) return;
        StringBuilder text = new StringBuilder();
        for (Map.Entry<Product, Integer> item : customer.getCart().getItems().entrySet()) {
            text.append(item.getKey().getName())
                    .append(" | quantity: ").append(item.getValue())
                    .append(" | subtotal: ")
                    .append(item.getKey().getPrice().multiply(BigDecimal.valueOf(item.getValue())))
                    .append(" VND\n");
        }
        if (text.length() == 0) text.append("Your cart is empty.");
        cartArea.setText(text.toString());
        totalLabel.setText("Total: " + customer.getCart().getTotalPrice().toPlainString() + " VND");
    }

    private void checkout() {
        if (customer.getCart().isEmpty()) {
            showError("Your cart is empty. Add a product before checkout.");
            return;
        }
        TextInputDialog recipientDialog = new TextInputDialog("Nguyen Van A");
        recipientDialog.setTitle("Checkout");
        recipientDialog.setHeaderText("Enter shipping details");
        recipientDialog.setContentText("Recipient name:");
        String recipient = recipientDialog.showAndWait().orElse("").trim();
        if (recipient.isEmpty()) return;

        String street = askText("Street address", "12 Le Loi");
        if (street == null || street.isBlank()) return;
        String city = askText("City", "Ha Noi");
        if (city == null || city.isBlank()) return;
        String country = askText("Country", "Vietnam");
        if (country == null || country.isBlank()) return;

        try {
            ShippingAddress address = new ShippingAddress(
                    "ADDR-" + (customer.getAddresses().size() + 1), recipient,
                    street, "", city, "", "", country);
            customer.addAddress(address);
            Order order = orderService.checkout(customer, address);
            refreshCart();
            refreshHistory();
            refreshProducts(searchField.getText());
            refreshAdminTable();
            showInfo("Order placed successfully!\n" + order);
        } catch (InvalidOrderException | OutOfStockException | IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }

    private String askText(String title, String defaultValue) {
        TextInputDialog dialog = new TextInputDialog(defaultValue);
        dialog.setTitle("Checkout");
        dialog.setHeaderText(title);
        dialog.setContentText(title + ":");
        return dialog.showAndWait().orElse(null);
    }

    private void refreshHistory() {
        if (historyArea == null) return;
        StringBuilder text = new StringBuilder();
        for (Order order : customer.getOrders()) text.append(order).append("\n");
        if (text.length() == 0) text.append("No orders yet.");
        historyArea.setText(text.toString());
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Operation failed");
        alert.setHeaderText("Please check your input");
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showInfo(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Online Shopping System");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
