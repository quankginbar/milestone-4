package model;

import service.ProductService;

public class Admin extends User {
    public Admin(String id, String username, String email, String password) {
        super(id, username, email, password);
    }

    public void addProduct(ProductService service, Product product) {
        service.addProduct(product);
    }

    public void editProduct(ProductService service, Product product) {
        service.updateProduct(product);
    }

    public void deleteProduct(ProductService service, String productId) {
        service.deleteProduct(productId);
    }

    public void updateInventory(ProductService service, String productId, int quantity) {
        service.updateInventory(productId, quantity);
    }
}
