package model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;
import exception.OutOfStockException;

public class Cart {
    private String id;
    private LocalDateTime createdAt = LocalDateTime.now();
    // Key = Product ID; value = quantity
    private Map<Product, Integer> items = new LinkedHashMap<>();

    public Cart(String id) { this.id = id; }

    public void addItem(Product product, int quantity) throws OutOfStockException {
        if (product == null) throw new IllegalArgumentException("Product is required.");
        if (quantity <= 0) throw new IllegalArgumentException("Quantity must be positive.");
        int current = items.containsKey(product) ? items.get(product) : 0;
        if (current + quantity > product.getStock())
            throw new OutOfStockException("Not enough stock for " + product.getName());
        items.put(product, current + quantity);
    }

    public void removeItem(Product product) { items.remove(product); }

    public void updateQuantity(Product product, int quantity) throws OutOfStockException {
        if (!items.containsKey(product)) throw new IllegalArgumentException("Product is not in cart.");
        if (quantity <= 0) {
            items.remove(product);
            return;
        }
        if (quantity > product.getStock())
            throw new OutOfStockException("Not enough stock for " + product.getName());
        items.put(product, quantity);
    }

    public BigDecimal getTotalPrice() {
        BigDecimal total = BigDecimal.ZERO;
        for (Map.Entry<Product, Integer> item : items.entrySet()) {
            total = total.add(item.getKey().getPrice()
                    .multiply(BigDecimal.valueOf(item.getValue())));
        }
        return total;
    }

    public Map<Product, Integer> getItems() { return new LinkedHashMap<>(items); }
    public boolean isEmpty() { return items.isEmpty(); }
    public void clearCart() { items.clear(); }
    public String getId() { return id; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
