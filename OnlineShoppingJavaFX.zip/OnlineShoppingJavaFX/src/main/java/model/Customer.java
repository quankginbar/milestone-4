package model;

import java.util.ArrayList;
import java.util.List;

public class Customer extends User {
    private Cart cart;
    private List<Order> orders = new ArrayList<>();
    private List<ShippingAddress> addresses = new ArrayList<>();

    public Customer(String id, String username, String email, String password) {
        super(id, username, email, password);
        cart = new Cart("CART-" + id);
    }

    public Cart getCart() { return cart; }
    public List<Order> getOrders() { return new ArrayList<>(orders); }
    public List<ShippingAddress> getAddresses() { return new ArrayList<>(addresses); }

    public void addAddress(ShippingAddress address) {
        if (address == null) throw new IllegalArgumentException("Address is required.");
        addresses.add(address);
    }

    public void addOrder(Order order) {
        if (order == null) throw new IllegalArgumentException("Order is required.");
        orders.add(order);
    }

    public void viewPurchaseHistory() {
        for (Order order : orders) System.out.println(order);
    }
}
