package model;

import service.ProductService;

public class Guest {
    public void browseProducts(ProductService service) {
        service.displayProducts();
    }

    public void searchProducts(ProductService service, String query) {
        service.searchProducts(query);
    }

    public void viewProductDetails(ProductService service, String productId) {
        System.out.println(service.getProduct(productId));
    }

    public void register() {
        System.out.println("Registration should be handled by an account service.");
    }
}
