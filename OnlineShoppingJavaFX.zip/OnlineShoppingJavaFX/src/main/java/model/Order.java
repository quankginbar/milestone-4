package model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;
import exception.InvalidOrderException;
import exception.OutOfStockException;

public class Order {
    public enum Status { PENDING, APPROVED, SHIPPED, DELIVERED, CANCELLED }

    private String id;
    private LocalDateTime createdAt = LocalDateTime.now();
    private Status status = Status.PENDING;
    private BigDecimal purchaseTotal;
    private Customer customer;
    private ShippingAddress shippingAddress;
    private Map<Product, Integer> items = new LinkedHashMap<>();

    public Order(String id, Customer customer, ShippingAddress address, Cart cart)
            throws InvalidOrderException, OutOfStockException {
        if (cart == null || cart.isEmpty()) throw new InvalidOrderException("Cart is empty.");
        if (customer == null || address == null) throw new InvalidOrderException("Customer and address are required.");

        this.id = id;
        this.customer = customer;
        this.shippingAddress = address;
        for (Map.Entry<Product, Integer> item : cart.getItems().entrySet()) {
            Product product = item.getKey();
            int quantity = item.getValue();
            if (quantity > product.getStock())
                throw new OutOfStockException("Insufficient stock for " + product.getName());
        }
        for (Map.Entry<Product, Integer> item : cart.getItems().entrySet()) {
            item.getKey().updateStock(-item.getValue());
            items.put(item.getKey(), item.getValue());
        }
        purchaseTotal = calculateTotal();
    }

    public BigDecimal calculateTotal() {
        BigDecimal total = BigDecimal.ZERO;
        for (Map.Entry<Product, Integer> item : items.entrySet()) {
            total = total.add(item.getKey().getPrice().multiply(BigDecimal.valueOf(item.getValue())));
        }
        return total;
    }

    public void cancelOrder() throws InvalidOrderException {
        if (status == Status.SHIPPED || status == Status.DELIVERED || status == Status.CANCELLED)
            throw new InvalidOrderException("This order cannot be cancelled.");
        for (Map.Entry<Product, Integer> item : items.entrySet())
            item.getKey().updateStock(item.getValue());
        status = Status.CANCELLED;
    }

    public void updateStatus(Status status) {
        if (status == null) throw new IllegalArgumentException("Status is required.");
        this.status = status;
    }

    public String getId() { return id; }
    public Status getStatus() { return status; }
    public BigDecimal getPurchaseTotal() { return purchaseTotal; }
    public Customer getCustomer() { return customer; }
    public ShippingAddress getShippingAddress() { return shippingAddress; }

    @Override
    public String toString() {
        return "Order " + id + " | total=" + purchaseTotal + " | status=" + status;
    }
}
