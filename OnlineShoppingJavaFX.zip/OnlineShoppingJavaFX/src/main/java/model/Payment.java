package model;

import java.math.BigDecimal;

public class Payment {
    public enum Method { CASH, CARD, BANK_TRANSFER }
    public enum Status { PENDING, SUCCESS, FAILED, REFUNDED }

    private String id;
    private Method method;
    private BigDecimal amount;
    private Status transactionStatus = Status.PENDING;

    public Payment(String id, Method method, BigDecimal amount) {
        if (id == null || id.isBlank() || method == null || amount == null
                || amount.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Invalid payment information.");
        }
        this.id = id;
        this.method = method;
        this.amount = amount;
    }

    // Demo implementation only; a real system needs a payment gateway.
    public boolean processPayment() {
        transactionStatus = Status.SUCCESS;
        return true;
    }

    public boolean refund() {
        if (transactionStatus != Status.SUCCESS) return false;
        transactionStatus = Status.REFUNDED;
        return true;
    }

    public Status getTransactionStatus() { return transactionStatus; }
    public BigDecimal getAmount() { return amount; }
}
