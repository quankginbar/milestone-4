package model;

import java.math.BigDecimal;

public class Product {
    private String id;
    private String name;
    private BigDecimal price;
    private int stock;
    private String description;
    private Category category;

    public Product(String id, String name, BigDecimal price, int stock,
                   String description, Category category) {
        if (id == null || id.isBlank() || name == null || name.isBlank())
            throw new IllegalArgumentException("Product ID and name are required.");
        if (price == null || price.compareTo(BigDecimal.ZERO) < 0)
            throw new IllegalArgumentException("Price must be non-negative.");
        if (stock < 0) throw new IllegalArgumentException("Stock cannot be negative.");
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.description = description;
        this.category = category;
    }

    public void updateStock(int quantityChange) {
        if (stock + quantityChange < 0)
            throw new IllegalArgumentException("Stock cannot become negative.");
        stock += quantityChange;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public BigDecimal getPrice() { return price; }
    public int getStock() { return stock; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }

    public void setName(String name) {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Name is required.");
        this.name = name;
    }
    public void setPrice(BigDecimal price) {
        if (price == null || price.compareTo(BigDecimal.ZERO) < 0)
            throw new IllegalArgumentException("Price must be non-negative.");
        this.price = price;
    }
    public void setDescription(String description) { this.description = description; }

    @Override
    public String toString() {
        return id + " | " + name + " | " + price + " | stock=" + stock;
    }
}
