package model;

public class ShippingAddress {
    private String id;
    private String recipientName;
    private String line1;
    private String line2;
    private String city;
    private String state;
    private String postalCode;
    private String country;

    public ShippingAddress(String id, String recipientName, String line1,
                           String line2, String city, String state,
                           String postalCode, String country) {
        if (id == null || id.isBlank() || recipientName == null || recipientName.isBlank()
                || line1 == null || line1.isBlank() || city == null || city.isBlank()
                || country == null || country.isBlank()) {
            throw new IllegalArgumentException("Required address fields are missing.");
        }
        this.id = id; this.recipientName = recipientName; this.line1 = line1;
        this.line2 = line2; this.city = city; this.state = state;
        this.postalCode = postalCode; this.country = country;
    }

    public String getId() { return id; }

    @Override
    public String toString() {
        return recipientName + ", " + line1 + ", " + city + ", " + country;
    }
}
