package service;

import java.util.HashMap;
import java.util.Map;
import model.Cart;
import model.Customer;
import model.Order;
import model.ShippingAddress;
import exception.InvalidOrderException;
import exception.OutOfStockException;

public class OrderService {
    private Map<String, Order> orders = new HashMap<>();
    private int nextId = 1;

    public Order checkout(Customer customer, ShippingAddress address)
            throws InvalidOrderException, OutOfStockException {
        Cart cart = customer.getCart();
        String orderId = "ORD-" + nextId++;
        Order order = new Order(orderId, customer, address, cart);
        orders.put(orderId, order);
        customer.addOrder(order);
        cart.clearCart();
        return order;
    }

    public Order getOrder(String id) throws InvalidOrderException {
        Order order = orders.get(id);
        if (order == null) throw new InvalidOrderException("Order not found: " + id);
        return order;
    }
}
