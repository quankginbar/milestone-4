package service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import model.Product;
import exception.ProductNotFoundException;

public class ProductService {
    private Map<String, Product> products = new HashMap<>();

    public void addProduct(Product product) {
        if (product == null) throw new IllegalArgumentException("Product is required.");
        if (products.containsKey(product.getId()))
            throw new IllegalArgumentException("Product ID already exists.");
        products.put(product.getId(), product);
    }

    public Product getProduct(String id) {
        Product product = products.get(id);
        if (product == null) throw new IllegalArgumentException("Product not found: " + id);
        return product;
    }

    public void updateProduct(Product product) {
        if (product == null || !products.containsKey(product.getId()))
            throw new IllegalArgumentException("Product does not exist.");
        products.put(product.getId(), product);
    }

    public void deleteProduct(String id) {
        if (products.remove(id) == null)
            throw new IllegalArgumentException("Product not found: " + id);
    }

    public void updateInventory(String id, int quantityChange) {
        getProduct(id).updateStock(quantityChange);
    }

    public List<Product> searchProducts(String query) {
        List<Product> result = new ArrayList<>();
        if (query == null) return result;
        for (Product product : products.values()) {
            if (product.getName().toLowerCase().contains(query.toLowerCase()))
                result.add(product);
        }
        return result;
    }

    public void displayProducts() {
        for (Product product : products.values()) System.out.println(product);
    }
}
